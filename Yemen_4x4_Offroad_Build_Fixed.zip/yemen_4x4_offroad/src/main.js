import * as THREE from 'three';
import './style.css';

const $ = (id) => document.getElementById(id);
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x9eb5bd);
scene.fog = new THREE.FogExp2(0xb3b9a0, 0.00165);
const camera = new THREE.PerspectiveCamera(62, innerWidth/innerHeight, 0.1, 1800);
const renderer = new THREE.WebGLRenderer({antialias:true, powerPreference:'high-performance'});
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.8));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.08;
$('game').appendChild(renderer.domElement);

scene.add(new THREE.HemisphereLight(0xdde9e5,0x6a5841,2.0));
const hemi = scene.children[0];
const sun = new THREE.DirectionalLight(0xffe2b4,2.3);
sun.position.set(-180,260,130); sun.castShadow=true; sun.shadow.mapSize.set(2048,2048);
sun.shadow.camera.left=-240;sun.shadow.camera.right=240;sun.shadow.camera.top=240;sun.shadow.camera.bottom=-240;scene.add(sun);

const regions = {
  sanaa:{name:'مرتفعات صنعاء',base:28,amp:62,rough:1.0,desert:false,seed:2},
  taiz:{name:'جبال تعز',base:20,amp:78,rough:1.25,desert:false,seed:7},
  hadramout:{name:'صحراء حضرموت',base:7,amp:23,rough:.72,desert:true,seed:11},
  tihama:{name:'سهول تهامة',base:5,amp:15,rough:.65,desert:true,seed:17}
};
const cities = {
 sanaa:{name:'صنعاء',x:-430,z:-390,profile:'sanaa'},
 aden:{name:'عدن',x:620,z:780,profile:'tihama'},
 taiz:{name:'تعز',x:-360,z:170,profile:'taiz'},
 ibb:{name:'إب',x:120,z:90,profile:'taiz'},
 dhamar:{name:'ذمار',x:-120,z:-650,profile:'sanaa'},
 marib:{name:'مأرب',x:570,z:-280,profile:'hadramout'},
 hodeidah:{name:'الحديدة',x:-930,z:270,profile:'tihama'},
 saada:{name:'صعدة',x:-560,z:-1080,profile:'taiz'},
 mukalla:{name:'المكلا',x:1120,z:360,profile:'tihama'},
 seiyun:{name:'سيئون',x:1120,z:-540,profile:'hadramout'}
};
let activeRegion=regions.sanaa, terrain, vehicle, wheels=[], speed=0, steer=0, yaw=0, verticalVelocity=0, cameraMode=0, started=false, destination=null, destinationMarker=null, nightMode=false;
const keys={gas:false,brake:false,reverse:false,left:false,right:false,handbrake:false};
const vehicleSpecs={
 hilux:{name:'هايلكس',mass:1,accel:24,max:52,grip:1.0,color:0xb9c4c0,body:[2.05,.78,4.25]},
 vxr:{name:'لاندكروزر VXR',mass:1.25,accel:19,max:48,grip:1.18,color:0xddd9c8,body:[2.25,.95,4.75]},
 shas:{name:'شاص',mass:.92,accel:22,max:47,grip:1.12,color:0x8b9a84,body:[1.95,.88,4.4]},
 quarter:{name:'جيب ربع',mass:.88,accel:25,max:50,grip:.98,color:0x9eaa9a,body:[1.9,.85,4.0]}
};
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const smooth=(a,b,t)=>a+(b-a)*t;
function hash(x,z){const n=Math.sin(x*127.1+z*311.7+activeRegion.seed*74.7)*43758.5453;return n-Math.floor(n)}
function heightAt(x,z){
 const r=activeRegion, f=r.rough;
 const broad=Math.sin(x*.007+z*.006)*.5+Math.cos(z*.009-x*.006)*.5;
 const ridges=Math.abs(Math.sin((x+z*.42)*.012))*Math.abs(Math.cos((z-x*.2)*.009));
 const detail=(Math.sin(x*.055+z*.07)*Math.cos(z*.065-x*.04)*.5+Math.sin(x*.14+z*.13)*.18);
 let h=r.base+r.amp*(.34*broad+.55*ridges)+detail*5*f;
 if(r.desert) h+=Math.sin(x*.022+z*.018)*5+Math.sin(z*.052)*2;
 // Broad wadi corridor through the playable valley.
 const wadi=Math.abs(x-(Math.sin(z*.0045)*110+Math.sin(z*.012)*28));
 h-=Math.exp(-wadi*wadi/1100)*(r.desert?8:18);
 return h;
}
function terrainMaterial(){
 const c=document.createElement('canvas');c.width=512;c.height=512;const ctx=c.getContext('2d');
 const img=ctx.createImageData(512,512);
 for(let y=0;y<512;y++)for(let x=0;x<512;x++){
  const n=hash(x,y), ridge=Math.sin(x*.035+y*.012)*.5+.5;
  let col=activeRegion.desert?[177,143,91]:[119,111,83];
  const k=(y*512+x)*4, shade=.78+n*.28+ridge*.12;
  img.data[k]=col[0]*shade;img.data[k+1]=col[1]*shade;img.data[k+2]=col[2]*shade;img.data[k+3]=255;
 }
 ctx.putImageData(img,0,0);const tex=new THREE.CanvasTexture(c);tex.wrapS=tex.wrapT=THREE.RepeatWrapping;tex.repeat.set(5,5);tex.colorSpace=THREE.SRGBColorSpace;return tex;
}
function makeTerrain(){
 if(terrain){scene.remove(terrain);terrain.geometry.dispose();terrain.material.dispose()}
 const size=3000,segments=260,geo=new THREE.PlaneGeometry(size,size,segments,segments);geo.rotateX(-Math.PI/2);
 const p=geo.attributes.position;
 for(let i=0;i<p.count;i++){const x=p.getX(i),z=p.getZ(i);p.setY(i,heightAt(x,z))}
 geo.computeVertexNormals();
 terrain=new THREE.Mesh(geo,new THREE.MeshStandardMaterial({map:terrainMaterial(),roughness:1,metalness:0}));
 terrain.receiveShadow=true;scene.add(terrain);
}
function makeRoadPath(points,width=6,color=0x77664a){
 const curve=new THREE.CatmullRomCurve3(points);
 const verts=[],indices=[],count=Math.max(80,points.length*22);
 for(let i=0;i<=count;i++){
  const t=i/count,p=curve.getPoint(t),tan=curve.getTangent(t),side=new THREE.Vector3(-tan.z,0,tan.x).normalize();
  const y=heightAt(p.x,p.z)+.85;
  verts.push(p.x-side.x*width/2,y,p.z-side.z*width/2,p.x+side.x*width/2,y,p.z+side.z*width/2);
  if(i<count){const a=i*2;indices.push(a,a+1,a+2,a+1,a+3,a+2)}
 }
 const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(verts,3));g.setIndex(indices);g.computeVertexNormals();
 const m=new THREE.Mesh(g,new THREE.MeshStandardMaterial({color,roughness:1,side:THREE.DoubleSide}));m.receiveShadow=true;scene.add(m);
}
function makeRoad(){
 // شبكة طرق رئيسية متعرجة تربط مراكز المحافظات داخل عالم اللعب.
 const center=(z)=>Math.sin(z*.0045)*110+Math.sin(z*.012)*28;
 const trunk=[];for(let z=-1420;z<=1420;z+=22){const x=center(z);trunk.push(new THREE.Vector3(x,0,z))}
 makeRoadPath(trunk,8,activeRegion.desert?0x9d8056:0x76634a);
 const hubs=Object.values(cities);
 for(const city of hubs){
  const joinZ=city.z*.55,joinX=center(joinZ);
  const pts=[new THREE.Vector3(joinX,0,joinZ),new THREE.Vector3((joinX+city.x)*.5+Math.sin(city.x)*35,0,(joinZ+city.z)*.5),new THREE.Vector3(city.x,0,city.z)];
  makeRoadPath(pts,5,0x8a7657);
 }
}
function addRock(x,z,s){
 const y=heightAt(x,z);const mesh=new THREE.Mesh(new THREE.DodecahedronGeometry(s,0),new THREE.MeshStandardMaterial({color:0x777260,roughness:1}));
 mesh.position.set(x,y+s*.25,z);mesh.scale.set(1,.65,1.2);mesh.rotation.set(hash(x,z)*.6,hash(z,x)*6,0);mesh.castShadow=true;mesh.receiveShadow=true;scene.add(mesh);
}
function addVillage(){
 const mats=[0xb69a70,0xc6ad82,0x8d8066,0xd0b98e].map(c=>new THREE.MeshStandardMaterial({color:c,roughness:1}));
 Object.entries(cities).forEach(([id,city],ci)=>{
  const count=['sanaa','aden','taiz','ibb','hodeidah','mukalla'].includes(id)?17:11;
  for(let i=0;i<count;i++){
   const x=city.x+(hash(i,ci)*105-52),z=city.z+(hash(ci,i+3)*95-47),y=heightAt(x,z);
   const w=5+hash(i,ci+8)*7,h=5+hash(i+4,ci)*12,d=5+hash(i,ci+4)*7;
   const b=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mats[(i+ci)%mats.length]);b.position.set(x,y+h/2,z);b.castShadow=true;b.receiveShadow=true;scene.add(b);
   const roof=new THREE.Mesh(new THREE.BoxGeometry(w*1.04,.5,d*1.04),new THREE.MeshStandardMaterial({color:0x625746}));roof.position.set(x,y+h+.2,z);roof.castShadow=true;scene.add(roof);
  }
  const canvas=document.createElement('canvas');canvas.width=512;canvas.height=128;const ctx=canvas.getContext('2d');
  ctx.fillStyle='#18241ddd';ctx.fillRect(0,0,512,128);ctx.fillStyle='#f1d39a';ctx.font='bold 46px sans-serif';ctx.textAlign='center';ctx.fillText(city.name,256,82);
  const tex=new THREE.CanvasTexture(canvas);const sprite=new THREE.Sprite(new THREE.SpriteMaterial({map:tex,transparent:true}));sprite.position.set(city.x,heightAt(city.x,city.z)+27,city.z);sprite.scale.set(42,10,1);scene.add(sprite);
 });
}
function buildWorld(){
 // Remove old world objects while preserving lights and vehicle.
 const keep=new Set([sun,hemi]);for(const o of [...scene.children])if(!keep.has(o)&&o!==vehicle)scene.remove(o);
 makeTerrain();makeRoad();addVillage();
 for(let i=0;i<560;i++){const x=(hash(i,5)-.5)*2850,z=(hash(7,i)-.5)*2850;if(Math.abs(x-(Math.sin(z*.012)*42+25))>12)addRock(x,z,1.5+hash(i,9)*6)}
}
function setDestination(id){
 destination=cities[id];if(!destination)return;
 if(destinationMarker)scene.remove(destinationMarker);
 const group=new THREE.Group();
 const beam=new THREE.Mesh(new THREE.CylinderGeometry(.22,.22,18,10),new THREE.MeshBasicMaterial({color:0xffd36d,transparent:true,opacity:.42}));
 beam.position.y=9;group.add(beam);
 const ring=new THREE.Mesh(new THREE.TorusGeometry(3.8,.22,8,28),new THREE.MeshBasicMaterial({color:0xffd36d}));ring.rotation.x=Math.PI/2;ring.position.y=.5;group.add(ring);
 group.position.set(destination.x,heightAt(destination.x,destination.z)+1,destination.z);scene.add(group);destinationMarker=group;
 $('destinationInfo').textContent='الوجهة: '+destination.name+' — تم تحديد المسار';
}
function updateNavigation(){
 if(!vehicle)return;
 let nearest=null,nearestDistance=Infinity;
 for(const city of Object.values(cities)){
  const cd=Math.hypot(city.x-vehicle.position.x,city.z-vehicle.position.z);
  if(cd<nearestDistance){nearestDistance=cd;nearest=city;}
 }
 if(nearest&&nearestDistance<260)$('locationName').textContent=nearest.name;
 else $('locationName').textContent='طرق اليمن المفتوحة';
 if(!destination)return;
 const d=Math.hypot(destination.x-vehicle.position.x,destination.z-vehicle.position.z);
 $('destinationInfo').textContent='الوجهة: '+destination.name+' — المسافة التقريبية '+(d/1000).toFixed(1)+' كم';
 if(destinationMarker)destinationMarker.rotation.y+=.012;
}
function toggleTime(){
 nightMode=!nightMode;
 scene.background=new THREE.Color(nightMode?0x111c2c:0x9eb5bd);
 scene.fog.color.set(nightMode?0x182333:0xb3b9a0);
 sun.intensity=nightMode?.32:2.3;
 hemi.intensity=nightMode?.35:2.0;
 $('weatherBtn').textContent=nightMode?'☾':'☼';
}
function makeVehicle(type){
 if(vehicle)scene.remove(vehicle);wheels=[];
 const spec=vehicleSpecs[type],group=new THREE.Group();
 const bodyMat=new THREE.MeshStandardMaterial({color:spec.color,metalness:.28,roughness:.48});
 const dark=new THREE.MeshStandardMaterial({color:0x202622,roughness:.8});
 const glass=new THREE.MeshStandardMaterial({color:0x31444a,metalness:.35,roughness:.18});
 const [w,h,l]=spec.body;
 const chassis=new THREE.Mesh(new THREE.BoxGeometry(w,h,l),bodyMat);chassis.position.y=1.25;chassis.castShadow=true;group.add(chassis);
 const cabin=new THREE.Mesh(new THREE.BoxGeometry(w*.88,.82,l*.48),bodyMat);cabin.position.set(0,2.02,-.25);cabin.castShadow=true;group.add(cabin);
 const windshield=new THREE.Mesh(new THREE.BoxGeometry(w*.84,.56,.035),glass);windshield.position.set(0,2.05,.0);windshield.rotation.x=-.18;group.add(windshield);
 const hood=new THREE.Mesh(new THREE.BoxGeometry(w*.9,.22,l*.27),bodyMat);hood.position.set(0,1.72,l*.32);group.add(hood);
 for(const x of [-1,1])for(const z of [-1,1]){
  const tire=new THREE.Mesh(new THREE.CylinderGeometry(.48,.48,.34,20),dark);tire.rotation.z=Math.PI/2;tire.position.set(x*(w/2+.12),.62,z*(l*.36));tire.castShadow=true;group.add(tire);wheels.push({mesh:tire,x,z,localX:x*(w/2+.12),localZ:z*(l*.36)});
  const rim=new THREE.Mesh(new THREE.CylinderGeometry(.23,.23,.355,12),new THREE.MeshStandardMaterial({color:0x9da5a2,metalness:.7,roughness:.3}));rim.rotation.z=Math.PI/2;rim.position.copy(tire.position);group.add(rim);
 }
 for(const x of [-.62,.62]){const lamp=new THREE.Mesh(new THREE.BoxGeometry(.42,.22,.06),new THREE.MeshStandardMaterial({color:0xffe7ad,emissive:0x55401c}));lamp.position.set(x,1.42,l/2+.04);group.add(lamp)}
 const bumper=new THREE.Mesh(new THREE.BoxGeometry(w*1.08,.2,.18),dark);bumper.position.set(0,.9,l/2+.08);group.add(bumper);
 group.position.set(25,heightAt(25,0)+.1,0);scene.add(group);vehicle=group;yaw=0;speed=0;verticalVelocity=0;
}
function resetToRegion(){
 const start=cities[$('regionSelect').value]||cities.sanaa;const startX=start.x,startZ=start.z;vehicle.position.set(startX,heightAt(startX,startZ)+.15,startZ);yaw=0;speed=0;verticalVelocity=0;vehicle.rotation.set(0,0,0);
}
function updateVehicle(dt){
 if(!vehicle)return;
 const spec=vehicleSpecs[$('vehicleSelect').value];
 const throttle=keys.gas?1:0,brake=keys.brake?1:0,reverse=keys.reverse?1:0;
 const steerInput=(keys.left?1:0)-(keys.right?1:0);
 const grip=spec.grip*(keys.handbrake?.48:1);
 if(throttle)speed+=spec.accel*dt;else if(reverse)speed-=spec.accel*.62*dt;else speed*=Math.pow(.994,dt*60);
 if(brake)speed*=Math.pow(.90,dt*60);
 if(keys.handbrake)speed*=Math.pow(.975,dt*60);
 speed=clamp(speed,-16,spec.max);
 const steerTarget=steerInput*clamp(Math.abs(speed)/9,.18,1)*.58;
 steer=smooth(steer,steerTarget,1-Math.exp(-dt*7));
 yaw+=steer*(speed>=0?1:-1)*dt*(.42+Math.abs(speed)*.018)*grip;
 const forward=new THREE.Vector3(Math.sin(yaw),0,Math.cos(yaw));
 vehicle.position.x+=forward.x*speed*dt;vehicle.position.z+=forward.z*speed*dt;
 const ground=heightAt(vehicle.position.x,vehicle.position.z)+.15;
 const targetY=ground+Math.sin(performance.now()*.006+speed*.04)*.025;
 verticalVelocity+=(targetY-vehicle.position.y)*30*dt;verticalVelocity*=Math.pow(.28,dt);vehicle.position.y+=verticalVelocity*dt;
 const front=heightAt(vehicle.position.x+forward.x*2,vehicle.position.z+forward.z*2),back=heightAt(vehicle.position.x-forward.x*2,vehicle.position.z-forward.z*2);
 const right=new THREE.Vector3(Math.cos(yaw),0,-Math.sin(yaw));
 const leftH=heightAt(vehicle.position.x-right.x,vehicle.position.z-right.z),rightH=heightAt(vehicle.position.x+right.x,vehicle.position.z+right.z);
 const pitch=clamp(Math.atan2(front-back,4),-.35,.35),roll=clamp(Math.atan2(leftH-rightH,2),-.32,.32);
 vehicle.rotation.order='YXZ';vehicle.rotation.y=yaw;vehicle.rotation.x=-pitch;vehicle.rotation.z=roll;
 wheels.forEach(w=>{
  w.mesh.rotation.x+=speed*dt*1.8;
  if(Math.abs(w.z)>.5)w.mesh.rotation.y=steer*.35;
  const wx=vehicle.position.x+Math.cos(yaw)*w.localX+Math.sin(yaw)*w.localZ;
  const wz=vehicle.position.z-Math.sin(yaw)*w.localX+Math.cos(yaw)*w.localZ;
  const wheelGround=heightAt(wx,wz);
  w.mesh.position.y=clamp(.62+(wheelGround-vehicle.position.y)*.48,.34,.96);
 });
 $('speed').textContent=Math.round(Math.abs(speed)*3.6);
 $('gear').textContent=reverse?'R':(brake&&Math.abs(speed)<.5?'N':'D');
}
const camTarget=new THREE.Vector3(),camPos=new THREE.Vector3();
function updateCamera(dt){
 if(!vehicle)return;
 const forward=new THREE.Vector3(Math.sin(yaw),0,Math.cos(yaw));
 if(cameraMode===0){camPos.copy(vehicle.position).addScaledVector(forward,-10);camPos.y+=5.2}
 else if(cameraMode===1){camPos.copy(vehicle.position).addScaledVector(forward,-17);camPos.y+=10}
 else {camPos.copy(vehicle.position).add(new THREE.Vector3(0,2.5,0));}
 camera.position.lerp(camPos,1-Math.exp(-dt*3.2));
 camTarget.copy(vehicle.position).addScaledVector(forward,cameraMode===2?12:5);camTarget.y+=1.2;camera.lookAt(camTarget);
}
function animate(now){requestAnimationFrame(animate);const dt=Math.min(clock.getDelta(),.04);if(started){updateVehicle(dt);updateCamera(dt);updateNavigation()}renderer.render(scene,camera)}
const clock=new THREE.Clock();
function startGame(){
 const startCity=cities[$('regionSelect').value]||cities.sanaa;activeRegion=regions[startCity.profile];$('locationName').textContent=startCity.name;
 buildWorld();makeVehicle($('vehicleSelect').value);resetToRegion();setDestination($('destinationSelect').value);started=true;
 $('menu').style.display='none';$('loading').classList.add('hide');
}
$('startBtn').addEventListener('click',startGame);
$('menuBtn').addEventListener('click',()=>{$('menu').style.display='grid';started=false});
$('mapBtn').addEventListener('click',()=>$('mapPanel').classList.toggle('open'));
$('closeMap').addEventListener('click',()=>$('mapPanel').classList.remove('open'));
$('destinationSelect').addEventListener('change',e=>setDestination(e.target.value));
$('weatherBtn').addEventListener('click',toggleTime);
$('cameraBtn').addEventListener('click',()=>{cameraMode=(cameraMode+1)%3;$('cameraBtn').textContent=['كاميرا','بعيدة','داخلية'][cameraMode]});
renderer.domElement.addEventListener('pointerdown',()=>{if(started)cameraMode=(cameraMode+1)%3});
document.querySelectorAll('[data-control]').forEach(btn=>{
 const key=btn.dataset.control;
 const down=e=>{e.preventDefault();keys[key]=true;btn.classList.add('active');};
 const up=e=>{e.preventDefault();keys[key]=false;btn.classList.remove('active');};
 btn.addEventListener('pointerdown',down);btn.addEventListener('pointerup',up);btn.addEventListener('pointerleave',up);btn.addEventListener('pointercancel',up);
});
addEventListener('keydown',e=>{const map={KeyW:'gas',ArrowUp:'gas',KeyS:'reverse',ArrowDown:'brake',KeyA:'left',ArrowLeft:'left',KeyD:'right',ArrowRight:'right',Space:'handbrake'};if(map[e.code]){keys[map[e.code]]=true;e.preventDefault()}if(e.code==='KeyC')cameraMode=(cameraMode+1)%3});
addEventListener('keyup',e=>{const map={KeyW:'gas',ArrowUp:'gas',KeyS:'reverse',ArrowDown:'brake',KeyA:'left',ArrowLeft:'left',KeyD:'right',ArrowRight:'right',Space:'handbrake'};if(map[e.code])keys[map[e.code]]=false});
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);renderer.setPixelRatio(Math.min(devicePixelRatio,1.8))});
buildWorld();makeVehicle('hilux');$('loading').classList.add('hide');requestAnimationFrame(animate);
